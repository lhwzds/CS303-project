Set of files published in FForum (a magazin of the Fédération Française d'Othello) containing problems to solve by programs.
