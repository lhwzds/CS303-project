/*
   File:           scrzebra.c

   Created:        November 17, 2001
   
   Modified:

   Author:         Gunnar Andersson (gunnar@radagast.se)

   Contents:
*/



#define SCRZEBRA



#include "zebra.c"

