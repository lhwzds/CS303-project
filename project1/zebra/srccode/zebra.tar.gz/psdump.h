
extern int
ps_dump_position( int *board, const char *file_name,
		  double image_size );

extern int
ps_dump_game( int *game, int move_count,
	      const char *file_name, double image_size );
