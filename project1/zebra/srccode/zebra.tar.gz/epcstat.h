/*
   epcstat.h

   Automatically created by CORRELA2 on Wed Nov 22 21:42:20 2000
*/


#ifndef ENDPCSTAT_H
#define ENDPCSTAT_H


#define MAX_END_CORR_DEPTH       8


extern float end_mean[61][MAX_END_CORR_DEPTH+1];

extern float end_sigma[61][MAX_END_CORR_DEPTH+1];

extern short end_stats_available[61][MAX_END_CORR_DEPTH+1];



#endif  /* ENDPCSTAT_H */
