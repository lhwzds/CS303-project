/*
   File:         porting.h

   Created:      November 4, 2001

   Modified:

   Author:       Gunnar Andersson (gunnar@radagast.se)

   Contents:     System-specific stuff.
*/



#ifndef PORTING_H
#define PORTING_H



#endif
