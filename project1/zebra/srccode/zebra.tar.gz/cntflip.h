/*
   cntflip.h

   Automatically created by ENDMACRO on Wed Mar 17 21:01:12 1999

   Last modified:   December 25, 1999
*/



#ifndef CNTFLIP_H
#define CNTFLIP_H



int
AnyFlips_compact( int *board, int sqnum, int color, int oppcol );



#endif  /* CNTFLIP_H */
